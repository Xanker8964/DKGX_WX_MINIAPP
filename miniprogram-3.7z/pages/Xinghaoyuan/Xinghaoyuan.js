Page({
  data: {
    headerData: [ '发射频率范围', '饱和输出功率', 'P-1dB输出功率'],
    tableData:[
      { col1: 'GXPA0618P4', data: ['6GHz~18GHz', '36dBm', '31dBm'] }
    ],
    scrollLeft: 0,
    scrollTop: 0,
    showFilterPopup: false,
    isPopupVisible: false,
    filterValues: [],
    modelFilter: '',
    originalTableData: [],
    visibleTableData: [],
    rowHeight: 80,
    viewHeight: 800,
    currentPage: 1,
    pageSize: 10,
    totalPages: 0,
    isDataEmpty: false
  },

  updateVisibleData() {
    const { tableData, currentPage, pageSize } = this.data;
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, tableData.length);
    const visibleTableData = tableData.slice(startIndex, endIndex);
    this.setData({
      visibleTableData,
      scrollTop: 0,
      scrollLeft: 0
    });
  },

  firstPage() {
    if (this.data.currentPage !== 1) {
      this.setData({
        currentPage: 1
      });
      this.updateVisibleData();
    }
  },

  prevPage() {
    if (this.data.currentPage > 1) {
      this.setData({
        currentPage: this.data.currentPage - 1
      });
      this.updateVisibleData();
    }
  },

  nextPage() {
    if (this.data.currentPage < this.data.totalPages) {
      this.setData({
        currentPage: this.data.currentPage + 1
      });
      this.updateVisibleData();
    }
  },

  lastPage() {
    if (this.data.currentPage !== this.data.totalPages) {
      this.setData({
        currentPage: this.data.totalPages
      });
      this.updateVisibleData();
    }
  },

  syncScrollY(e) {
    const scrollTop = e.detail.scrollTop;
    this.setData({ scrollTop });
  },

  goToDetail(e) {
    const model = e.currentTarget.dataset.model;
    const rowData = this.data.tableData.find(item => item.col1 === model);
    const rowDataString = JSON.stringify(rowData);
    wx.navigateTo({
      url: `/pages/Xinghaoyuan/detail/detail?rowData=${encodeURIComponent(rowDataString)}`
    });
  },

  openFilterPopup() {
    this.setData({
      showFilterPopup: true,
      isPopupVisible: true,
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: ''
    });
  },

  closeFilterPopup() {
    this.setData({ isPopupVisible: false });
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  inputFilter(e) {
    const index = e.currentTarget.dataset.index;
    const value = e.detail.value;
    let filterValues = this.data.filterValues;
    filterValues[index] = value;
    this.setData({ filterValues });
  },

  inputModelFilter(e) {
    const value = e.detail.value;
    this.setData({ modelFilter: value });
  },

  applyFilter() {
    const filterValues = this.data.filterValues;
    const modelFilter = this.data.modelFilter;
    const originalData = this.data.originalTableData;
  
    let filteredData = originalData;
  
    // 型号筛选
    if (modelFilter) {
      filteredData = filteredData.filter(row => 
        row.col1.toLowerCase().includes(modelFilter.toLowerCase())
      );
    }
  
    // 按列筛选
    filteredData = filteredData.filter(row => {
      return row.data.every((cell, index) => {
        const filterValue = filterValues[index];
        if (!filterValue) return true;
  
        // 特殊处理发射频率范围列 (index === 0)
        if (index === 0) {
          // 替换 DC 为 0 并去除单位 GHz
          const rangeStr = cell.replace('DC', '0').replace(/GHz/g, '');
          // 解析频率范围，如 "6~18"
          const [start, end] = rangeStr.split('~').map(val => parseFloat(val.trim()));
          const inputValue = parseFloat(filterValue);
          // 检查输入值是否在范围内
          return !isNaN(start) && !isNaN(end) && !isNaN(inputValue) && 
                 inputValue >= start && inputValue <= end;
        }
  
        // 其他列保持字符串包含逻辑
        return cell.toString().toLowerCase().includes(filterValue.toLowerCase());
      });
    });
  
    this.setData({
      isPopupVisible: false
    });
  
    setTimeout(() => {
      this.setData({
        tableData: filteredData,
        currentPage: 1,
        totalPages: Math.ceil(filteredData.length / this.data.pageSize),
        scrollTop: 0,
        showFilterPopup: false,
        isDataEmpty: filteredData.length === 0
      });
      this.updateVisibleData();
    }, 300);
  },

  clearFilter() {
    this.setData({
      tableData: this.data.originalTableData,
      currentPage: 1,
      totalPages: Math.ceil(this.data.originalTableData.length / this.data.pageSize),
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      isPopupVisible: false,
      scrollTop: 0,
      isDataEmpty: false
    });
    this.updateVisibleData();
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  stopPropagation(e) {},

  onLoad() {
    const totalPages = Math.ceil(this.data.tableData.length / this.data.pageSize);
    this.setData({
      originalTableData: this.data.tableData,
      totalPages,
      currentPage: 1,
      isDataEmpty: false
    });
    this.updateVisibleData();
  }
});