// pages/chipGaAs/chipGaAs.js
Page({
    clickGaAsLowamp:function(e){
      wx.navigateTo({
        url: '/pages/chipGaAsLowamp/chipGaAsLowamp'
      })
    },

    clickGaAsAMPd:function(e){
      wx.navigateTo({
        url: '/pages/chipGaAsAMPd/chipGaAsAMPd'
      })
    },

    clickHunping:function(e){
      wx.navigateTo({
        url: '/pages/chipHunping/chipHunping'
      })
    },

    clickKaiguan:function(e){
       wx.navigateTo({
         url: '/pages/chipKaiguan/chipKaiguan'
       })
    },

    clickShukongsj:function(e){
      wx.navigateTo({
        url: '/pages/chipShukongsj/chipShukongsj'
      })
    },

    clickGudingsj:function(e){
      wx.navigateTo({
        url: '/pages/chipGudingsj/chipGudingsj'
      })
    },

    clickKebiansj:function(e){
      wx.navigateTo({
        url: '/pages/chipKebiansj/chipKebiansj'
      })
    },

    clickShukongyx:function(e){
      wx.navigateTo({
        url: '/pages/chipShukongyx/chipShukongyx'
      })
    },

    clickJunheng:function(e){
      wx.navigateTo({
        url: '/pages/chipJunheng/chipJunheng'
      })
    },

    clickXianfu:function(e){
      wx.navigateTo({
        url: '/pages/chipXianfu/chipXianfu'
      })
    },

    clickOuhe:function(e){
      wx.navigateTo({
        url: '/pages/chipOuhe/chipOuhe'
      })
    },

    click2waygongfen:function(e){
      wx.navigateTo({
        url: '/pages/chip2waygongfen/chip2waygongfen'
      })
    },

    click3waygongfen:function(e){
      wx.navigateTo({
        url: '/pages/chip3waygongfen/chip3waygongfen'
      })
    },
    onShareAppMessage: function () {
      // 函数体内容为空即可
  },
    onShareTimeline() {
    // 设置分享朋友圈内容
    return {
      title: '分享标题',
      query: 'key=value'
    }
  }











})