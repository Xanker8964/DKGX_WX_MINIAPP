Page({
  data: {
    headerData: ['增益(dB)', '噪声系数(dB)', '输出P-1dB(dBm)', '电源(V/mA)', '芯片尺寸(mm)'],
    tableData: [
      { col1: 'GX1001P', frequency: '0.2~4', data: ['18.4', '1.4', '14.5', '+5/45', 'QFN3x3 塑料封装'] },
      { col1: 'GX1001C', frequency: '0.2~4', data: ['18.2', '1.5', '15', '+5/45', 'QFN3x3 陶瓷封装'] },
      { col1: 'GX1068P', frequency: '0.2~4', data: ['18.4', '1.0', '20', '+5/50', 'STSLP2x2 塑料封装'] },
      { col1: 'GX1075', frequency: '0.7~5', data: ['14', '2.2', '20', '+5/65', '1.43x1.15x0.08'] },
      { col1: 'GX1043', frequency: '0.8~2.6', data: ['30', '1.4', '15', '+5/45', '1.80x1.80x0.10'] },
      { col1: 'GX1083', frequency: '1~12', data: ['14', '2.2', '15', '+5/50', '1.70x1.30x0.07'] },
      { col1: 'GX1002', frequency: '2~3', data: ['30', '0.44', '18.6', '+5/45', '1.80x1.40x0.10'] },
      { col1: 'GX1002P', frequency: '2~3', data: ['30', '0.9', '17.6', '+5/51', 'QFN3x3 塑料封装'] },
      { col1: 'GX1027', frequency: '2~6', data: ['23.2', '3.9', '18', '+5/86', '1.60x1.60x0.10'] },
      { col1: 'GX1076', frequency: '2~6', data: ['25', '1.0', '10', '+5/45', '1.90x1.20x0.07'] },
      { col1: 'GX1058', frequency: '2~6', data: ['17', '1.1', '12', '+5/68', '1.70x1.00x0.10'] },
      { col1: 'GX1059', frequency: '2~6', data: ['27', '0.8', '15.6', '+5/55', '1.70x1.00x0.10'] },
      { col1: 'GX1004', frequency: '2~20', data: ['18', '2.9', '10', '+5/35', '2.09x1.40x0.10'] },
      { col1: 'GX1005', frequency: '2~20', data: ['21', '2.5', '11', '+5/37', '2.10x1.00x0.10'] },
      { col1: 'GX1078', frequency: '2~20', data: ['17', '2.5', '15', '+5/70', '3.10x1.30x0.07'] },
      { col1: 'GX1080', frequency: '2~20', data: ['18', '2.5', '19', '+5/100', '2.80x1.30x0.07'] },
      { col1: 'GX1081', frequency: '2~20', data: ['25', '1.7', '13.5', '+5/70', '1.90x1.00x0.07'] },
      { col1: 'GX1006', frequency: '4~7', data: ['25', '0.8', '13.5', '+5/49', '1.79x1.00x0.10'] },
      { col1: 'GX1007', frequency: '4~8', data: ['23', '0.8', '11', '+5/41', '1.79x1.10x0.10'] },
      { col1: 'GX1028', frequency: '4~8', data: ['23', '1.5', '16.5', '+5/58', '1.60x1.00x0.10'] },
      { col1: 'GX1008', frequency: '5~7', data: ['24', '0.7', '14.5', '+5/70', '1.49x1.10x0.10'] },
      { col1: 'GX1009', frequency: '5~9', data: ['25', '0.9', '10', '+5/31', '1.79x1.10x0.10'] },
      { col1: 'GX1010', frequency: '6~12', data: ['26.8', '1.7', '15.5', '+5/115', '2.00x1.10x0.10'] },
      { col1: 'GX1032', frequency: '6~12', data: ['21', '2.3', '17', '+5/74', '1.60x1.00x0.10'] },
      { col1: 'GX1082', frequency: '6~12', data: ['19', '1.8', '18', '+5/80', '1.30x1.00x0.07'] },
      { col1: 'GX1011', frequency: '6~14', data: ['21.5', '1.4', '13.5', '+5/49', '1.50x1.00x0.10'] },
      { col1: 'GX1012', frequency: '6~18', data: ['25', '1.5', '12', '+5/34', '1.90x1.00x0.10'] },
      { col1: 'GX1013', frequency: '6~18', data: ['26', '1.6', '14.8', '+5/55', '1.90x1.00x0.10'] },
      { col1: 'GX1014', frequency: '6~18', data: ['25.8', '1.5', '14.5', '+5/50', '1.90x1.00x0.10'] },
      { col1: 'GX1029', frequency: '6~18', data: ['22', '2.0', '15', '+5/76', '2.10x1.00x0.10'] },
      { col1: 'GX1033', frequency: '6~18', data: ['19', '2.5', '18.5', '+5/88', '1.60x1.00x0.10'] },
      { col1: 'GX1034', frequency: '6~18', data: ['18.8', '2.5', '17.8', '+5/88', '1.60x1.00x0.10'] },
      { col1: 'GX1077', frequency: '6~18', data: ['27', '1.8', '10', '+5/55', '2.65x1.25x0.07'] },
      { col1: 'GX1016', frequency: '8~12', data: ['23', '0.8', '13', '+5/39', '1.69x1.00x0.10'] },
      { col1: 'GX1018', frequency: '8~13', data: ['20.5', '1.0', '11.5', '+5/39', '1.50x0.90x0.10'] },
      { col1: 'GX1079', frequency: '8~20', data: ['17', '2.5', '14', '+5/75', '2.90x1.30x0.07'] },
      { col1: 'GX1035', frequency: '10~13', data: ['20', '1.2', '6.5', '+5/12', '1.10x0.80x0.10'] },
      { col1: 'GX1035P', frequency: '10~13', data: ['20', '1.6', '7.5', '+5/12', 'QFN3x3 塑封封装'] },
      { col1: 'GX1054', frequency: '10~13', data: ['17.2', '1.5', '9', '+4/20', '1.00x1.00x0.10'] },
      { col1: 'GX1046', frequency: '10~15', data: ['23', '1.1', '12', '+5/33', '1.70x1.00x0.10'] },
      { col1: 'GX1047A', frequency: '10~15', data: ['21.5', '1.4', '16.5', '+5/76', '1.00x0.80x0.10'] },
      { col1: 'GX1047B', frequency: '10~15', data: ['23.2', '1.4', '16.5', '+5/77', '1.70x1.00x0.10'] },
      { col1: 'GX1019', frequency: '12~18', data: ['27', '1.5', '13', '+5/42', '2.10x0.90x0.10'] },
      { col1: 'GXL1044', frequency: '14~18', data: ['28.5', '1.55', '8', '+5/23', '1.7x1.1x0.1(限幅器)'] },
      { col1: 'GXL1051B', frequency: '14~18', data: ['24', '1.55', '7', '+5/23', '1.35x0.94x0.1(限幅器)'] },
      { col1: 'GXL1051C', frequency: '14~18', data: ['24', '1.75', '7.5', '+5/23', '1.16x0.76x0.1(限幅器)'] },
      { col1: 'GX1020', frequency: '14~19', data: ['21.6', '1.4', '11.5', '+5/33', '2.00x1.00x0.10'] },
      { col1: 'GX1030', frequency: '17~21', data: ['20', '4.0', '9.5', '+5/37', '1.60x1.00x0.10'] },
      { col1: 'GX1051', frequency: '17~22', data: ['24.4', '1.5', '7', '+5/24', '1.70x1.00x0.10'] },
      { col1: 'GX1055', frequency: '17~22', data: ['24.4', '1.4', '13', '+4/40', '2.50x1.00x0.10'] },
      { col1: 'GX1022', frequency: '18~25', data: ['22', '1.3', '6', '+5/14', '1.79x1.10x0.10'] },
      { col1: 'GX1023', frequency: '18~25', data: ['25.2', '1.8', '5', '+5/14', '2.10x0.90x0.10'] },
      { col1: 'GX1063', frequency: '18~40', data: ['16', '3.0', '14', '+5/60', '1.70x1.00x0.10'] },
      { col1: 'GX1024', frequency: '22~32', data: ['24', '2.5', '2.5', '+5/13', '1.50x1.00x0.10'] },
      { col1: 'GX1025', frequency: '22~32', data: ['24', '2.1', '-1', '+5/13', '1.50x0.90x0.10'] },
      { col1: 'GX1084', frequency: '35~45', data: ['19.6', '2.5', '10', '+2/55', '1.40x0.82x0.10'] },
      { col1: 'GX1085', frequency: '35~45', data: ['13', '3.0', '14', '+5/37', '1.80x0.82x0.10'] },
      { col1: 'GX1086', frequency: '5~24', data: ['20', '1.3', '0', '+5/10', '1.85x1.15x0.10'] },
      { col1: 'GX1087', frequency: '1~12', data: ['25', '1.0', '15', '+5/50', '1.85x1.25x0.10'] }
    ],
    scrollLeft: 0,
    scrollTop: 0,
    showFilterPopup: false,
    isPopupVisible: false,
    filterValues: [],
    modelFilter: '',
    frequencyFilter: '',
    originalTableData: [],
    visibleTableData: [],
    visibleFrequencyData: [],
    rowHeight: 80,
    viewHeight: 800,
    currentPage: 1,
    pageSize: 10,
    totalPages: 0,
    isDataEmpty: false,
    activeFilters: []
  },

  updateVisibleData() {
    const { tableData, currentPage, pageSize } = this.data;
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, tableData.length);
    const visibleTableData = tableData.slice(startIndex, endIndex);
    const visibleFrequencyData = tableData.slice(startIndex, endIndex).map(item => item.frequency);
    this.setData({
      visibleTableData,
      visibleFrequencyData,
      scrollTop: 0,
      scrollLeft: 0
    });
  },

  firstPage() {
    if (this.data.currentPage !== 1) {
      this.setData({
        currentPage: 1
      });
      this.updateVisibleData();
    }
  },

  prevPage() {
    if (this.data.currentPage > 1) {
      this.setData({
        currentPage: this.data.currentPage - 1
      });
      this.updateVisibleData();
    }
  },

  nextPage() {
    if (this.data.currentPage < this.data.totalPages) {
      this.setData({
        currentPage: this.data.currentPage + 1
      });
      this.updateVisibleData();
    }
  },

  lastPage() {
    if (this.data.currentPage !== this.data.totalPages) {
      this.setData({
        currentPage: this.data.totalPages
      });
      this.updateVisibleData();
    }
  },

  syncScrollY(e) {
    const scrollTop = e.detail.scrollTop;
    this.setData({ scrollTop });
  },

  goToDetail(e) {
    const model = e.currentTarget.dataset.model;
    const rowData = this.data.tableData.find(item => item.col1 === model);
    const rowDataString = JSON.stringify(rowData);
    wx.navigateTo({
      url: `/pages/chipGaAsLowamp/detail/detail?rowData=${encodeURIComponent(rowDataString)}`
    });
  },

  openFilterPopup() {
    this.setData({
      showFilterPopup: true,
      isPopupVisible: true,
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: ''
    });
  },

  closeFilterPopup() {
    this.setData({ isPopupVisible: false });
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  inputFilter(e) {
    const index = e.currentTarget.dataset.index;
    const value = e.detail.value;
    let filterValues = this.data.filterValues;
    filterValues[index] = value;
    this.setData({ filterValues });
  },

  inputModelFilter(e) {
    const value = e.detail.value;
    this.setData({ modelFilter: value });
  },

  inputFrequencyFilter(e) {
    const value = e.detail.value;
    this.setData({ frequencyFilter: value });
  },

  applyFilter() {
    const { filterValues, modelFilter, frequencyFilter, originalTableData } = this.data;
    let filteredData = originalTableData;

    // 型号筛选
    if (modelFilter) {
      filteredData = filteredData.filter(row => 
        row.col1.toLowerCase().includes(modelFilter.toLowerCase())
      );
    }

    // 工作频率筛选
    if (frequencyFilter) {
      filteredData = filteredData.filter(row => {
        const [tableStart, tableEnd] = row.frequency.split('~').map(val => parseFloat(val.trim()));
        let inputStart, inputEnd;
        if (frequencyFilter.includes('~')) {
          [inputStart, inputEnd] = frequencyFilter.split('~').map(val => parseFloat(val.trim()));
        } else if (frequencyFilter.includes('-')) {
          [inputStart, inputEnd] = frequencyFilter.split('-').map(val => parseFloat(val.trim()));
        } else {
          inputStart = parseFloat(frequencyFilter);
          inputEnd = inputStart;
        }
        if (isNaN(inputStart) || isNaN(inputEnd) || isNaN(tableStart) || isNaN(tableEnd)) {
          return false;
        }
        return tableStart <= inputStart && tableEnd >= inputEnd;
      });
    }

    // 其他列筛选
    filteredData = filteredData.filter(row => {
      return row.data.every((cell, index) => {
        const filterValue = filterValues[index];
        if (!filterValue) return true;
        return cell.toString().toLowerCase().includes(filterValue.toLowerCase());
      });
    });

    // 收集当前应用的筛选条件
    const activeFilters = [];
    if (modelFilter) {
      activeFilters.push({ label: '型号', value: modelFilter });
    }
    if (frequencyFilter) {
      activeFilters.push({ label: '工作频率(GHz)', value: frequencyFilter });
    }
    filterValues.forEach((value, index) => {
      if (value) {
        activeFilters.push({ label: this.data.headerData[index], value });
      }
    });

    this.setData({
      isPopupVisible: false,
      activeFilters
    });

    setTimeout(() => {
      this.setData({
        tableData: filteredData,
        currentPage: 1,
        totalPages: Math.ceil(filteredData.length / this.data.pageSize),
        scrollTop: 0,
        showFilterPopup: false,
        isDataEmpty: filteredData.length === 0
      });
      this.updateVisibleData();
    }, 300);
  },

  clearFilter() {
    this.setData({
      tableData: this.data.originalTableData,
      currentPage: 1,
      totalPages: Math.ceil(this.data.originalTableData.length / this.data.pageSize),
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: '',
      isPopupVisible: false,
      scrollTop: 0,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  stopPropagation(e) {},

  onLoad(options) {
    const totalPages = Math.ceil(this.data.tableData.length / this.data.pageSize);
    this.setData({
      originalTableData: this.data.tableData,
      totalPages,
      currentPage: 1,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();

    // 处理从Search页面传递的筛选参数
    if (options.modelFilter || options.filterValues || options.frequencyFilter) {
      const modelFilter = options.modelFilter || '';
      const filterValues = options.filterValues ? JSON.parse(decodeURIComponent(options.filterValues)) : [];
      const frequencyFilter = options.frequencyFilter || '';
      this.setData({
        modelFilter,
        filterValues,
        frequencyFilter
      });
      this.applyFilter();
    }
  }
});