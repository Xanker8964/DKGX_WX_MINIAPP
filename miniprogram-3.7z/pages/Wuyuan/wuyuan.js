// pages/chipGaN/chipGaN.js
Page({
  clickHPQ:function(e){
    wx.navigateTo({
      url: '/pages/chipHunping/chipHunping'
    })
  },

  clickXFQ:function(e){
    wx.navigateTo({
      url: '/pages/chipXianfu/chipXianfu'
    })
  },

  click2GFQ:function(e){
    wx.navigateTo({
      url: '/pages/chip2waygongfen/chip2waygongfen'
    })
  },

  click3GFQ:function(e){
    wx.navigateTo({
      url: '/pages/chip3waygongfen/chip3waygongfen'
    })
  },

  clickJHQ:function(e){
    wx.navigateTo({
      url: '/pages/chipJunheng/chipJunheng'
    })
  },
  
  clickOHQ:function(e){
    wx.navigateTo({
      url: '/pages/chipOuhe/chipOuhe'
    })
  },
})