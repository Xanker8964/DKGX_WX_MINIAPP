Page({
  data: {
    headerData: ['功率增益 (dB)', '输出 Psat (dBm)', '效率 (%)', '电源 (V)', '芯片尺寸 (mm)'],
    tableData: [
      { col1: 'GX3026', frequency: 'DC~2', data: ['11', '39.5', '37', '+28', '2.60x1.55x0.10'] },
      { col1: 'GX3001', frequency: '0.1~2.5', data: ['17', '37', '30', '+28', '2.40x1.60x0.10'] },
      { col1: 'GX3037', frequency: '0.2~2', data: ['12', '40', '43', '+28', '3.00x1.50x0.10'] },
      { col1: 'GX3024', frequency: '1.8~2.7', data: ['26', '44.5', '58', '+28', '3.20x1.95x0.10'] },
      { col1: 'GX3046', frequency: '2~6.5', data: ['20(PS),19(CW)', '47(PS),46(CW)', '45(PS),40(CW)', '+28', '2.67×3.69×0.1'] },
      { col1: 'GX3015', frequency: '2~6', data: ['17', '41', '45', '+28', '2.60x2.10x0.10'] },
      { col1: 'GX3036', frequency: '2~6', data: ['21', '46.5', '35', '+28', '4.05x4.00x0.10'] },
      { col1: 'GX3017', frequency: '2~18', data: ['8.5', '33', '12', '+28', '2.60x2.00x0.10'] },
      { col1: 'GX3018', frequency: '2~18', data: ['7', '38', '20', '+28', '4.70x2.60x0.10'] },
      { col1: 'GX3049', frequency: '2.5~3.5', data: ['27', '42', '55', '+28', '2.62×1.64×0.1'] },
      { col1: 'GX3002', frequency: '2.7~3.5', data: ['26', '46', '53', '+28', '3.50x2.50x0.10'] },
      { col1: 'GX3025', frequency: '3.5~4.5', data: ['18', '41', '50', '+28', '2.60x1.60x0.10'] },
      { col1: 'GX3032', frequency: '4~8', data: ['16', '40', '36', '+28', '2.40x1.60x0.10'] },
      { col1: 'GX3004', frequency: '4~8', data: ['13', '43', '40', '+28', '3.30x2.50x0.10'] },
      { col1: 'GX3005', frequency: '4~8', data: ['17', '45', '35', '+28', '3.20x3.20x0.10'] },
      { col1: 'GX3006', frequency: '5~7', data: ['17', '40.5', '44', '+28', '2.40x1.60x0.10'] },
      { col1: 'GX3033', frequency: '5~7', data: ['21', '41', '45', '+28', '2.00x1.60x0.10'] },
      { col1: 'GX3034', frequency: '5~7', data: ['20', '42', '47', '+28', '2.40x1.70x0.10'] },
      { col1: 'GX3041', frequency: '5~7', data: ['19', '42', '45', '+28', '2.00x1.50x0.10'] },
      { col1: 'GX3040', frequency: '5.3~7.5', data: ['17', '43.5', '50', '+28', '2.00x1.50x0.10'] },
      { col1: 'GX3008', frequency: '5.5~6.5', data: ['21', '40.5', '45', '+28', '2.00x1.45x0.10'] },
      { col1: 'GX3047', frequency: '6~18', data: ['20(PS),19(CW)', '45(PS),44(CW)', '35(PS),32(CW)', '+28', '2.87×2.87×0.1'] },
      { col1: 'GX3039', frequency: '6~18', data: ['18.5', '41.8', '25', '+28', '4.00x3.00x0.10'] },
      { col1: 'GX3035', frequency: '7~13', data: ['18', '39', '32', '+28', '2.80x1.65x0.10'] },
      { col1: 'GX3048', frequency: '7~13', data: ['19', '30', '27', '+28', '1.72×1.12×0.1'] },
      { col1: 'GX3009', frequency: '8~10', data: ['15', '39', '40', '+28', '2.00x1.20x0.10'] },
      { col1: 'GX3010', frequency: '8~10', data: ['15', '44', '40', '+28', '2.40x2.50x0.10'] },
      { col1: 'GX3011', frequency: '8~10', data: ['19', '46', '40', '+28', '3.20x3.20x0.10'] },
      { col1: 'GX3012', frequency: '8~12', data: ['14', '45', '35', '+28', '3.50x3.20x0.10'] },
      { col1: 'GX3038', frequency: '8~12', data: ['22', '48', '40', '+28', '4.05x5.00x0.10'] },
      { col1: 'GX3020', frequency: '10~17', data: ['12', '27.5', '15', '+28', '1.90x0.96x0.10'] },
      { col1: 'GX3013', frequency: '13~14', data: ['—', '43', '28', '+28', '2.45x3.53x0.10'] },
      { col1: 'GX3021', frequency: '13~16', data: ['20', '35.5', '30', '+28', '2.05x1.60x0.10'] },
      { col1: 'GX3023', frequency: '13~16', data: ['17', '42', '30', '+28', '3.10x2.20x0.10'] },
      { col1: 'GX3014', frequency: '14~18', data: ['—', '40', '30', '+28', '3.00x2.00x0.10'] },
      { col1: 'GX3022', frequency: '14~18', data: ['15', '41', '30', '+28', '3.10x2.20x0.10'] },
      { col1: 'GX3027', frequency: '14~18', data: ['20', '42', '36', '+28', '3.00x2.00x0.08'] },
      { col1: 'GX3029', frequency: '15~18', data: ['23.5', '44.5', '35', '+28', '3.60x3.50x0.08'] }
    ],
    scrollLeft: 0,
    scrollTop: 0,
    showFilterPopup: false,
    isPopupVisible: false,
    filterValues: [],
    modelFilter: '',
    frequencyFilter: '',
    originalTableData: [],
    visibleTableData: [],
    visibleFrequencyData: [],
    rowHeight: 80,
    viewHeight: 800,
    currentPage: 1,
    pageSize: 10,
    totalPages: 0,
    isDataEmpty: false,
    activeFilters: []
  },

  updateVisibleData() {
    const { tableData, currentPage, pageSize } = this.data;
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, tableData.length);
    const visibleTableData = tableData.slice(startIndex, endIndex);
    const visibleFrequencyData = tableData.slice(startIndex, endIndex).map(item => item.frequency);
    this.setData({
      visibleTableData,
      visibleFrequencyData,
      scrollTop: 0,
      scrollLeft: 0
    });
  },

  firstPage() {
    if (this.data.currentPage !== 1) {
      this.setData({
        currentPage: 1
      });
      this.updateVisibleData();
    }
  },

  prevPage() {
    if (this.data.currentPage > 1) {
      this.setData({
        currentPage: this.data.currentPage - 1
      });
      this.updateVisibleData();
    }
  },

  nextPage() {
    if (this.data.currentPage < this.data.totalPages) {
      this.setData({
        currentPage: this.data.currentPage + 1
      });
      this.updateVisibleData();
    }
  },

  lastPage() {
    if (this.data.currentPage !== this.data.totalPages) {
      this.setData({
        currentPage: this.data.totalPages
      });
      this.updateVisibleData();
    }
  },

  syncScrollY(e) {
    const scrollTop = e.detail.scrollTop;
    this.setData({ scrollTop });
  },

  goToDetail(e) {
    const model = e.currentTarget.dataset.model;
    const rowData = this.data.tableData.find(item => item.col1 === model);
    const rowDataString = JSON.stringify(rowData);
    wx.navigateTo({
      url: `/pages/chipGaNampd/detail/detail?rowData=${encodeURIComponent(rowDataString)}`
    });
  },

  openFilterPopup() {
    this.setData({
      showFilterPopup: true,
      isPopupVisible: true,
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: ''
    });
  },

  closeFilterPopup() {
    this.setData({ isPopupVisible: false });
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  inputFilter(e) {
    const index = e.currentTarget.dataset.index;
    const value = e.detail.value;
    let filterValues = this.data.filterValues;
    filterValues[index] = value;
    this.setData({ filterValues });
  },

  inputModelFilter(e) {
    const value = e.detail.value;
    this.setData({ modelFilter: value });
  },

  inputFrequencyFilter(e) {
    const value = e.detail.value;
    this.setData({ frequencyFilter: value });
  },

  applyFilter() {
    const { filterValues, modelFilter, frequencyFilter, originalTableData } = this.data;
    let filteredData = originalTableData;

    // 型号筛选
    if (modelFilter) {
      filteredData = filteredData.filter(row => 
        row.col1.toLowerCase().includes(modelFilter.toLowerCase())
      );
    }

    // 工作频率筛选
    if (frequencyFilter) {
      filteredData = filteredData.filter(row => {
        const rangeStr = row.frequency.replace('DC', '0');
        const [tableStart, tableEnd] = rangeStr.split('~').map(val => parseFloat(val.trim()));
        let inputStart, inputEnd;
        if (frequencyFilter.includes('~')) {
          [inputStart, inputEnd] = frequencyFilter.split('~').map(val => parseFloat(val.trim()));
        } else if (frequencyFilter.includes('-')) {
          [inputStart, inputEnd] = frequencyFilter.split('-').map(val => parseFloat(val.trim()));
        } else {
          inputStart = parseFloat(frequencyFilter);
          inputEnd = inputStart;
        }
        if (isNaN(inputStart) || isNaN(inputEnd) || isNaN(tableStart) || isNaN(tableEnd)) {
          return false;
        }
        return tableStart <= inputStart && tableEnd >= inputEnd;
      });
    }

    // 其他列筛选
    filteredData = filteredData.filter(row => {
      return row.data.every((cell, index) => {
        const filterValue = filterValues[index];
        if (!filterValue) return true;
        return cell.toString().toLowerCase().includes(filterValue.toLowerCase());
      });
    });

    // 收集当前应用的筛选条件
    const activeFilters = [];
    if (modelFilter) {
      activeFilters.push({ label: '型号', value: modelFilter });
    }
    if (frequencyFilter) {
      activeFilters.push({ label: '工作频率(GHz)', value: frequencyFilter });
    }
    filterValues.forEach((value, index) => {
      if (value) {
        activeFilters.push({ label: this.data.headerData[index], value });
      }
    });

    this.setData({
      isPopupVisible: false,
      activeFilters
    });

    setTimeout(() => {
      this.setData({
        tableData: filteredData,
        currentPage: 1,
        totalPages: Math.ceil(filteredData.length / this.data.pageSize),
        scrollTop: 0,
        showFilterPopup: false,
        isDataEmpty: filteredData.length === 0
      });
      this.updateVisibleData();
    }, 300);
  },

  clearFilter() {
    this.setData({
      tableData: this.data.originalTableData,
      currentPage: 1,
      totalPages: Math.ceil(this.data.originalTableData.length / this.data.pageSize),
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: '',
      isPopupVisible: false,
      scrollTop: 0,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  stopPropagation(e) {},

  onLoad(options) {
    const totalPages = Math.ceil(this.data.tableData.length / this.data.pageSize);
    this.setData({
      originalTableData: this.data.tableData,
      totalPages,
      currentPage: 1,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();

    // 处理从Search页面传递的筛选参数
    if (options.modelFilter || options.filterValues || options.frequencyFilter) {
      const modelFilter = options.modelFilter || '';
      const filterValues = options.filterValues ? JSON.parse(decodeURIComponent(options.filterValues)) : [];
      const frequencyFilter = options.frequencyFilter || '';
      this.setData({
        modelFilter,
        filterValues,
        frequencyFilter
      });
      this.applyFilter();
    }
  },

  onShareAppMessage: function () {},

  onShareTimeline() {
    return {
      title: '分享标题',
      query: 'key=value'
    };
  }
});