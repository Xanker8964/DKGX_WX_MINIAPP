

Page({
  onShareAppMessage: function () {
    // 函数体内容为空即可
},
  onShareTimeline() {
  // 设置分享朋友圈内容
  return {
    title: '分享标题',
    query: 'key=value'
  }
},
onCallPhone() {
  wx.makePhoneCall({
    phoneNumber: '028-86100186', // 要拨打的电话号码
  });
}
})