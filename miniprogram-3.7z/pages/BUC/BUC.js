Page({
  data: {
    headerData: [ '输入频段','输出频段', '功率', '增益'],
    tableData:[
      
        { col1: 'GXBUC-L_X-47', data: ['950MHz~1450MHz', '7.9GHz~8.4GHz', '47dBm', '50dB', ] },
        { col1: 'GXBUC-L_Ku-46.5', data: ['950MHz~1450MHz', '14GHz~14.5GHz', '46dBm', '69dB', ] },
        { col1: 'GXBUC-L_Ka-47', data: ['950MHz~1450MHz', '30GHz~31GHz', '47dBm', '50dB', ] },
        { col1: 'GXBUC-L_Ka-39', data: ['950MHz~2150MHz', '27.5GHz~31GHz', '39dBm', '55dB', ] },
        { col1: 'GXBUC-L_Ka-50', data: ['950MHz~2150MHz', '27.5GHz~30GHz', '50dBm', '68dB', ] },
        { col1: 'GXBUC-L_Ka-53', data: ['950MHz~2150MHz', '27.5GHz~31.5GHz', '53dBm', '70dB', ] }
  
    ],
    scrollLeft: 0,
    scrollTop: 0,
    showFilterPopup: false,
    isPopupVisible: false,
    filterValues: [],
    modelFilter: '',
    originalTableData: [],
    visibleTableData: [],
    rowHeight: 80,
    viewHeight: 800,
    currentPage: 1,
    pageSize: 10,
    totalPages: 0,
    isDataEmpty: false
  },

  updateVisibleData() {
    const { tableData, currentPage, pageSize } = this.data;
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, tableData.length);
    const visibleTableData = tableData.slice(startIndex, endIndex);
    this.setData({
      visibleTableData,
      scrollTop: 0,
      scrollLeft: 0
    });
  },

  firstPage() {
    if (this.data.currentPage !== 1) {
      this.setData({
        currentPage: 1
      });
      this.updateVisibleData();
    }
  },

  prevPage() {
    if (this.data.currentPage > 1) {
      this.setData({
        currentPage: this.data.currentPage - 1
      });
      this.updateVisibleData();
    }
  },

  nextPage() {
    if (this.data.currentPage < this.data.totalPages) {
      this.setData({
        currentPage: this.data.currentPage + 1
      });
      this.updateVisibleData();
    }
  },

  lastPage() {
    if (this.data.currentPage !== this.data.totalPages) {
      this.setData({
        currentPage: this.data.totalPages
      });
      this.updateVisibleData();
    }
  },

  syncScrollY(e) {
    const scrollTop = e.detail.scrollTop;
    this.setData({ scrollTop });
  },

  goToDetail(e) {
    const model = e.currentTarget.dataset.model;
    const rowData = this.data.tableData.find(item => item.col1 === model);
    const rowDataString = JSON.stringify(rowData);
    wx.navigateTo({
      url: `/pages/BUC/detail/detail?rowData=${encodeURIComponent(rowDataString)}`
    });
  },

  openFilterPopup() {
    this.setData({
      showFilterPopup: true,
      isPopupVisible: true,
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: ''
    });
  },

  closeFilterPopup() {
    this.setData({ isPopupVisible: false });
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  inputFilter(e) {
    const index = e.currentTarget.dataset.index;
    const value = e.detail.value;
    let filterValues = this.data.filterValues;
    filterValues[index] = value;
    this.setData({ filterValues });
  },

  inputModelFilter(e) {
    const value = e.detail.value;
    this.setData({ modelFilter: value });
  },
  applyFilter() {
    const filterValues = this.data.filterValues;
    const modelFilter = this.data.modelFilter;
    const originalData = this.data.originalTableData;
  
    let filteredData = originalData;
  
    // 型号筛选
    if (modelFilter) {
      filteredData = filteredData.filter(row => 
        row.col1.toLowerCase().includes(modelFilter.toLowerCase())
      );
    }
  
    // 按列筛选
    filteredData = filteredData.filter(row => {
      return row.data.every((cell, index) => {
        const filterValue = filterValues[index];
        if (!filterValue) return true;
  
        // 特殊处理输入频段 (index === 0) 和输出频段 (index === 1)
        if (index === 0 || index === 1) {
          // 替换 DC 为 0
          let rangeStr = cell.replace('DC', '0');
          let isMHz = rangeStr.includes('MHz');
          // 去除单位
          rangeStr = rangeStr.replace(/GHz|MHz/g, '');
          // 解析频段范围，如 "950~1450" 或 "7.9~8.4"
          let [start, end] = rangeStr.split('~').map(val => parseFloat(val.trim()));
          // 如果是 MHz，转换为 GHz
          //if (isMHz) {
          //start = start / 1000;
          //end = end / 1000;
          //}
          const inputValue = parseFloat(filterValue);
          // 检查输入值是否在范围内
          return !isNaN(start) && !isNaN(end) && !isNaN(inputValue) && 
                 inputValue >= start && inputValue <= end;
        }
  
        // 其他列保持字符串包含逻辑
        return cell.toString().toLowerCase().includes(filterValue.toLowerCase());
      });
    });
  
    this.setData({
      isPopupVisible: false
    });
  
    setTimeout(() => {
      this.setData({
        tableData: filteredData,
        currentPage: 1,
        totalPages: Math.ceil(filteredData.length / this.data.pageSize),
        scrollTop: 0,
        showFilterPopup: false,
        isDataEmpty: filteredData.length === 0
      });
      this.updateVisibleData();
    }, 300);
  },
  clearFilter() {
    this.setData({
      tableData: this.data.originalTableData,
      currentPage: 1,
      totalPages: Math.ceil(this.data.originalTableData.length / this.data.pageSize),
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      isPopupVisible: false,
      scrollTop: 0,
      isDataEmpty: false
    });
    this.updateVisibleData();
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  stopPropagation(e) {},

  onLoad() {
    const totalPages = Math.ceil(this.data.tableData.length / this.data.pageSize);
    this.setData({
      originalTableData: this.data.tableData,
      totalPages,
      currentPage: 1,
      isDataEmpty: false
    });
    this.updateVisibleData();
  }
});