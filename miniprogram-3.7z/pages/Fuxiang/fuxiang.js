// pages/chipGaN/chipGaN.js
Page({
  clickSKYX:function(e){
    wx.navigateTo({
      url: '/pages/chipShukongyx/chipShukongyx'
    })
  },

  clickSKSJ:function(e){
    wx.navigateTo({
      url: '/pages/chipShukongsj/chipShukongsj'
    })
  },

  clickGDSJ:function(e){
    wx.navigateTo({
      url: '/pages/chipGudingsj/chipGudingsj'
    })
  },

  clickKBSJ:function(e){
    wx.navigateTo({
      url: '/pages/chipKebiansj/chipKebiansj'
    })
  }

  
})