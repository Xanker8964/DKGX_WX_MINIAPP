
Page({
  data: {
    headerData: ['位数(bit)', '插损(dB)', '衰减范围(dB)', '附加相移(◦)', '输入驻波', '输出驻波', '控制电平(V)', '芯片尺寸(mm)'],
    tableData: [
      { col1: 'GX8007', frequency: 'DC~6', data: ['6', '2.2', '0.5~31.5', '±40', '1.4', '1.4', '0/+5', '2.94x1.20x0.10'] },
      { col1: 'GX8006', frequency: 'DC~8', data: ['6', '1.7', '0.5~31.5', '±4', '1.3', '1.3', '0/+3', '1.95x1.25x0.10'] },
      { col1: 'GX8018', frequency: 'DC~12', data: ['6', '2.8', '0.5~15.75', '±4', '1.5', '1.5', '0/+5', '2.40x1.20x0.10'] },
      { col1: 'GX8019', frequency: 'DC~12', data: ['6', '4.1', '0.5~31.5', '±5', '1.5', '1.5', '0/+5', '2.40x1.20x0.10'] },
      { col1: 'GX8005', frequency: 'DC~18', data: ['6', '4.5', '0.5~31.5', '±2', '1.3', '1.3', '0/+5', '2.40x1.20x0.10'] },
      { col1: 'GX8035', frequency: 'DC~18', data: ['6', '3', '0.5~31.5', '±5', '1.4', '1.4', '0/+5', '2.58x1.04x0.10'] },
      { col1: 'GX8040', frequency: '0.1~8', data: ['6', '2.5', '0.5~31.5', '±5', '1.4', '1.4', '0/+5', '2.40x1.40x0.10'] },
      { col1: 'GX8041', frequency: 'DC~20', data: ['6', '2.8', '0.5~31.5', '-', '-', '-', '0/+5', '1.55x0.99x0.10'] }
    ],
    scrollLeft: 0,
    scrollTop: 0,
    showFilterPopup: false,
    isPopupVisible: false,
    filterValues: [],
    modelFilter: '',
    frequencyFilter: '',
    originalTableData: [],
    visibleTableData: [],
    visibleFrequencyData: [],
    rowHeight: 80,
    viewHeight: 800,
    currentPage: 1,
    pageSize: 10,
    totalPages: 0,
    isDataEmpty: false,
    activeFilters: []
  },

  updateVisibleData() {
    const { tableData, currentPage, pageSize } = this.data;
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, tableData.length);
    const visibleTableData = tableData.slice(startIndex, endIndex);
    const visibleFrequencyData = tableData.slice(startIndex, endIndex).map(item => item.frequency);
    this.setData({
      visibleTableData,
      visibleFrequencyData,
      scrollTop: 0,
      scrollLeft: 0
    });
  },

  firstPage() {
    if (this.data.currentPage !== 1) {
      this.setData({
        currentPage: 1
      });
      this.updateVisibleData();
    }
  },

  prevPage() {
    if (this.data.currentPage > 1) {
      this.setData({
        currentPage: this.data.currentPage - 1
      });
      this.updateVisibleData();
    }
  },

  nextPage() {
    if (this.data.currentPage < this.data.totalPages) {
      this.setData({
        currentPage: this.data.currentPage + 1
      });
      this.updateVisibleData();
    }
  },

  lastPage() {
    if (this.data.currentPage !== this.data.totalPages) {
      this.setData({
        currentPage: this.data.totalPages
      });
      this.updateVisibleData();
    }
  },

  syncScrollY(e) {
    const scrollTop = e.detail.scrollTop;
    this.setData({ scrollTop });
  },

  goToDetail(e) {
    const model = e.currentTarget.dataset.model;
    const rowData = this.data.tableData.find(item => item.col1 === model);
    const rowDataString = JSON.stringify(rowData);
    wx.navigateTo({
      url: `/pages/chipShukongsj/detail/detail?rowData=${encodeURIComponent(rowDataString)}`
    });
  },

  openFilterPopup() {
    this.setData({
      showFilterPopup: true,
      isPopupVisible: true,
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: ''
    });
  },

  closeFilterPopup() {
    this.setData({ isPopupVisible: false });
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  inputFilter(e) {
    const index = e.currentTarget.dataset.index;
    const value = e.detail.value;
    let filterValues = this.data.filterValues;
    filterValues[index] = value;
    this.setData({ filterValues });
  },

  inputModelFilter(e) {
    const value = e.detail.value;
    this.setData({ modelFilter: value });
  },

  inputFrequencyFilter(e) {
    const value = e.detail.value;
    this.setData({ frequencyFilter: value });
  },

  applyFilter() {
    const { filterValues, modelFilter, frequencyFilter, originalTableData } = this.data;
    let filteredData = originalTableData;

    // 型号筛选
    if (modelFilter) {
      filteredData = filteredData.filter(row => 
        row.col1.toLowerCase().includes(modelFilter.toLowerCase())
      );
    }

    // 工作频率筛选
    if (frequencyFilter) {
      filteredData = filteredData.filter(row => {
        const rangeStr = row.frequency.replace('DC', '0');
        const [tableStart, tableEnd] = rangeStr.split('~').map(val => parseFloat(val.trim()));
        let inputStart, inputEnd;
        if (frequencyFilter.includes('~')) {
          [inputStart, inputEnd] = frequencyFilter.split('~').map(val => parseFloat(val.trim()));
        } else if (frequencyFilter.includes('-')) {
          [inputStart, inputEnd] = frequencyFilter.split('-').map(val => parseFloat(val.trim()));
        } else {
          inputStart = parseFloat(frequencyFilter);
          inputEnd = inputStart;
        }
        if (isNaN(inputStart) || isNaN(inputEnd) || isNaN(tableStart) || isNaN(tableEnd)) {
          return false;
        }
        return tableStart <= inputStart && tableEnd >= inputEnd;
      });
    }

    // 其他列筛选
    filteredData = filteredData.filter(row => {
      return row.data.every((cell, index) => {
        const filterValue = filterValues[index];
        if (!filterValue) return true;

        // 特殊处理衰减范围 (index === 2 in headerData)
        if (index === 2) {
          const rangeStr = cell.replace('DC', '0');
          const [tableStart, tableEnd] = rangeStr.split('~').map(val => parseFloat(val.trim()));
          let inputStart, inputEnd;
          if (filterValue.includes('~')) {
            [inputStart, inputEnd] = filterValue.split('~').map(val => parseFloat(val.trim()));
          } else if (filterValue.includes('-')) {
            [inputStart, inputEnd] = filterValue.split('-').map(val => parseFloat(val.trim()));
          } else {
            inputStart = parseFloat(filterValue);
            inputEnd = inputStart;
          }
          if (isNaN(inputStart) || isNaN(inputEnd) || isNaN(tableStart) || isNaN(tableEnd)) {
            return false;
          }
          return tableStart <= inputStart && tableEnd >= inputEnd;
        }

        // 其他列保持字符串包含逻辑
        return cell.toString().toLowerCase().includes(filterValue.toLowerCase());
      });
    });

    // 收集当前应用的筛选条件
    const activeFilters = [];
    if (modelFilter) {
      activeFilters.push({ label: '型号', value: modelFilter });
    }
    if (frequencyFilter) {
      activeFilters.push({ label: '工作频率(GHz)', value: frequencyFilter });
    }
    filterValues.forEach((value, index) => {
      if (value) {
        activeFilters.push({ label: this.data.headerData[index], value });
      }
    });

    this.setData({
      isPopupVisible: false,
      activeFilters
    });

    setTimeout(() => {
      this.setData({
        tableData: filteredData,
        currentPage: 1,
        totalPages: Math.ceil(filteredData.length / this.data.pageSize),
        scrollTop: 0,
        showFilterPopup: false,
        isDataEmpty: filteredData.length === 0
      });
      this.updateVisibleData();
    }, 300);
  },

  clearFilter() {
    this.setData({
      tableData: this.data.originalTableData,
      currentPage: 1,
      totalPages: Math.ceil(this.data.originalTableData.length / this.data.pageSize),
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: '',
      isPopupVisible: false,
      scrollTop: 0,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  stopPropagation(e) {},

  onLoad(options) {
    const totalPages = Math.ceil(this.data.tableData.length / this.data.pageSize);
    this.setData({
      originalTableData: this.data.tableData,
      totalPages,
      currentPage: 1,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();

    // 处理从Search页面传递的筛选参数
    if (options.modelFilter || options.filterValues || options.frequencyFilter) {
      const modelFilter = options.modelFilter || '';
      const filterValues = options.filterValues ? JSON.parse(decodeURIComponent(options.filterValues)) : [];
      const frequencyFilter = options.frequencyFilter || '';
      this.setData({
        modelFilter,
        filterValues,
        frequencyFilter
      });
      this.applyFilter();
    }
  },

  onShareAppMessage: function () {
    // 函数体内容为空即可
  },

  onShareTimeline() {
    // 设置分享朋友圈内容
    return {
      title: '分享标题',
      query: 'key=value'
    }
  }
});
