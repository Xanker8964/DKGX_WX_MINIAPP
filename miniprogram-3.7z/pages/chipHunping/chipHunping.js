
Page({
  data: {
    headerData: ['中频范围 (GHz)', '变换损耗 (dB)', 'LO-RF 隔离度 (dB)', 'LO-IF 隔离度 (dB)', 'RF-IF 隔离度 (dB)', '本振功率 (dBm)', '芯片尺寸 (mm)'],
    tableData: [
      { col1: 'GX6002', frequency: '3~10', data: ['DC~3', '8', '30', '28', '10', '17', '1.60x1.10x0.10'] },
      { col1: 'GX6008', frequency: '4~12', data: ['DC~4', '8', '50', '42', '25', '14', '1.80x1.40x0.10'] },
      { col1: 'GX6008M', frequency: '4~12', data: ['DC~4', '8', '50', '42', '25', '14', '1.80x1.40x0.10'] },
      { col1: 'GX6001', frequency: '6~18', data: ['DC~5', '9', '25', '35', '10', '13', '1.60x1.10x0.10'] },
      { col1: 'GX6009', frequency: '6~18', data: ['DC~5', '10', '35', '35', '10', '13', '1.54x1.04x0.10'] },
      { col1: 'GX6004', frequency: '7~14', data: ['DC~5', '8', '30', '30', '10', '13', '1.60x1.10x0.10'] },
      { col1: 'GX6003', frequency: '10~18', data: ['DC~5', '9', '30', '30', '10', '13', '1.60x1.10x0.10'] },
      { col1: 'GX6006', frequency: '18~32', data: ['DC~14', '9', '40', '35', '6', '13', '1.00x0.70x0.10'] },
      { col1: 'GX6007', frequency: '20~40', data: ['DC~18', '9', '30', '28', '12', '13', '1.00x0.70x0.10'] },
      { col1: 'GX6010', frequency: '6~20', data: ['DC~6', '8', '30', '30', '30', '10', '1.50x1.60x0.10'] }
    ],
    scrollLeft: 0,
    scrollTop: 0,
    showFilterPopup: false,
    isPopupVisible: false,
    filterValues: [],
    modelFilter: '',
    frequencyFilter: '',
    originalTableData: [],
    visibleTableData: [],
    visibleFrequencyData: [],
    rowHeight: 80,
    viewHeight: 800,
    currentPage: 1,
    pageSize: 10,
    totalPages: 0,
    isDataEmpty: false,
    activeFilters: []
  },

  updateVisibleData() {
    const { tableData, currentPage, pageSize } = this.data;
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, tableData.length);
    const visibleTableData = tableData.slice(startIndex, endIndex);
    const visibleFrequencyData = tableData.slice(startIndex, endIndex).map(item => item.frequency);
    this.setData({
      visibleTableData,
      visibleFrequencyData,
      scrollTop: 0,
      scrollLeft: 0
    });
  },

  firstPage() {
    if (this.data.currentPage !== 1) {
      this.setData({
        currentPage: 1
      });
      this.updateVisibleData();
    }
  },

  prevPage() {
    if (this.data.currentPage > 1) {
      this.setData({
        currentPage: this.data.currentPage - 1
      });
      this.updateVisibleData();
    }
  },

  nextPage() {
    if (this.data.currentPage < this.data.totalPages) {
      this.setData({
        currentPage: this.data.currentPage + 1
      });
      this.updateVisibleData();
    }
  },

  lastPage() {
    if (this.data.currentPage !== this.data.totalPages) {
      this.setData({
        currentPage: this.data.totalPages
      });
      this.updateVisibleData();
    }
  },

  syncScrollY(e) {
    const scrollTop = e.detail.scrollTop;
    this.setData({ scrollTop });
  },

  goToDetail(e) {
    const model = e.currentTarget.dataset.model;
    const rowData = this.data.tableData.find(item => item.col1 === model);
    const rowDataString = JSON.stringify(rowData);
    wx.navigateTo({
      url: `/pages/chipHunping/detail/detail?rowData=${encodeURIComponent(rowDataString)}`
    });
  },

  openFilterPopup() {
    this.setData({
      showFilterPopup: true,
      isPopupVisible: true,
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: ''
    });
  },

  closeFilterPopup() {
    this.setData({ isPopupVisible: false });
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  inputFilter(e) {
    const index = e.currentTarget.dataset.index;
    const value = e.detail.value;
    let filterValues = this.data.filterValues;
    filterValues[index] = value;
    this.setData({ filterValues });
  },

  inputModelFilter(e) {
    const value = e.detail.value;
    this.setData({ modelFilter: value });
  },

  inputFrequencyFilter(e) {
    const value = e.detail.value;
    this.setData({ frequencyFilter: value });
  },

  applyFilter() {
    const { filterValues, modelFilter, frequencyFilter, originalTableData } = this.data;
    let filteredData = originalTableData;

    // 型号筛选
    if (modelFilter) {
      filteredData = filteredData.filter(row => 
        row.col1.toLowerCase().includes(modelFilter.toLowerCase())
      );
    }

    // 频率范围RF&LO筛选
    if (frequencyFilter) {
      filteredData = filteredData.filter(row => {
        const rangeStr = row.frequency.replace('DC', '0');
        const [tableStart, tableEnd] = rangeStr.split('~').map(val => parseFloat(val.trim()));
        let inputStart, inputEnd;
        if (frequencyFilter.includes('~')) {
          [inputStart, inputEnd] = frequencyFilter.split('~').map(val => parseFloat(val.trim()));
        } else if (frequencyFilter.includes('-')) {
          [inputStart, inputEnd] = frequencyFilter.split('-').map(val => parseFloat(val.trim()));
        } else {
          inputStart = parseFloat(frequencyFilter);
          inputEnd = inputStart;
        }
        if (isNaN(inputStart) || isNaN(inputEnd) || isNaN(tableStart) || isNaN(tableEnd)) {
          return false;
        }
        return tableStart <= inputStart && tableEnd >= inputEnd;
      });
    }

    // 其他列筛选
    filteredData = filteredData.filter(row => {
      return row.data.every((cell, index) => {
        const filterValue = filterValues[index];
        if (!filterValue) return true;

        // 特殊处理中频范围 (index === 0 in headerData)
        if (index === 0) {
          const rangeStr = cell.replace('DC', '0');
          const [tableStart, tableEnd] = rangeStr.split('~').map(val => parseFloat(val.trim()));
          let inputStart, inputEnd;
          if (filterValue.includes('~')) {
            [inputStart, inputEnd] = filterValue.split('~').map(val => parseFloat(val.trim()));
          } else if (filterValue.includes('-')) {
            [inputStart, inputEnd] = filterValue.split('-').map(val => parseFloat(val.trim()));
          } else {
            inputStart = parseFloat(filterValue);
            inputEnd = inputStart;
          }
          if (isNaN(inputStart) || isNaN(inputEnd) || isNaN(tableStart) || isNaN(tableEnd)) {
            return false;
          }
          return tableStart <= inputStart && tableEnd >= inputEnd;
        }

        // 其他列保持字符串包含逻辑
        return cell.toString().toLowerCase().includes(filterValue.toLowerCase());
      });
    });

    // 收集当前应用的筛选条件
    const activeFilters = [];
    if (modelFilter) {
      activeFilters.push({ label: '型号', value: modelFilter });
    }
    if (frequencyFilter) {
      activeFilters.push({ label: '频率范围RF&LO(GHz)', value: frequencyFilter });
    }
    filterValues.forEach((value, index) => {
      if (value) {
        activeFilters.push({ label: this.data.headerData[index], value });
      }
    });

    this.setData({
      isPopupVisible: false,
      activeFilters
    });

    setTimeout(() => {
      this.setData({
        tableData: filteredData,
        currentPage: 1,
        totalPages: Math.ceil(filteredData.length / this.data.pageSize),
        scrollTop: 0,
        showFilterPopup: false,
        isDataEmpty: filteredData.length === 0
      });
      this.updateVisibleData();
    }, 300);
  },

  clearFilter() {
    this.setData({
      tableData: this.data.originalTableData,
      currentPage: 1,
      totalPages: Math.ceil(this.data.originalTableData.length / this.data.pageSize),
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: '',
      isPopupVisible: false,
      scrollTop: 0,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  stopPropagation(e) {},

  onLoad(options) {
    const totalPages = Math.ceil(this.data.tableData.length / this.data.pageSize);
    this.setData({
      originalTableData: this.data.tableData,
      totalPages,
      currentPage: 1,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();

    // 处理从Search页面传递的筛选参数
    if (options.modelFilter || options.filterValues || options.frequencyFilter) {
      const modelFilter = options.modelFilter || '';
      const filterValues = options.filterValues ? JSON.parse(decodeURIComponent(options.filterValues)) : [];
      const frequencyFilter = options.frequencyFilter || '';
      this.setData({
        modelFilter,
        filterValues,
        frequencyFilter
      });
      this.applyFilter();
    }
  },

  onShareAppMessage: function () {
    // 函数体内容为空即可
  },

  onShareTimeline() {
    // 设置分享朋友圈内容
    return {
      title: '分享标题',
      query: 'key=value'
    }
  }
});
