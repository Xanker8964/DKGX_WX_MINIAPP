
Page({
  data: {
    headerData: ['增益(dB)', '输出Psat(dBm)', '效率(%)', '电源(V/Vg)', '芯片尺寸(mm)'],
    tableData: [
      { col1: 'GX2029P', frequency: '0.1~2', data: ['21', '24(输出P-1)', '-', '+7', 'QFN3x3 塑封封装'] },
      { col1: 'GX2027P', frequency: 'DC~8', data: ['14.5', '22(输出P-1)', '-', '+9', 'QFN3x3 塑封封装'] },
      { col1: 'GX2001', frequency: '0.8~2', data: ['35.2', '33.5', '40', '+8/-0.7', '4.28x2.34x0.10'] },
      { col1: 'GX2030', frequency: '0.05~6', data: ['20', '16(输出P-1)', '-', '+5', '0.59x0.70x0.07'] },
      { col1: 'GX1065', frequency: '1~16', data: ['16', '16(输出P-1)', '-', '+5', '1.60x1.00x0.10'] },
      { col1: 'GX2002', frequency: '2~5', data: ['30', '21', '45', '+4/+0.6', '1.70x1.79x0.10'] },
      { col1: 'GX2003', frequency: '2~6', data: ['26', '29.6', '38', '+7/-0.7', '2.69x2.40x0.10'] },
      { col1: 'GX2031', frequency: '2~6', data: ['26', '22', '-', '+5', '1.50x1.00x0.07'] },
      { col1: 'GX1056', frequency: '2~18', data: ['13', '17(输出P-1)', '-', '+5', '1.70x1.00x0.07'] },
      { col1: 'GX2004', frequency: '4~5', data: ['31', '39', '37.5', '+9/-0.7', '3.70x3.80x0.10'] },
      { col1: 'GX2028', frequency: '4~7', data: ['21', '27', '30', '+7/-0.7', '1.64x1.24x0.10'] },
      { col1: 'GX2005', frequency: '4~8', data: ['24', '28', '48', '+7/-0.7', '1.61x1.60x0.10'] },
      { col1: 'GX2006', frequency: '5~20', data: ['20', '23', '38', '+4/+4', '1.70x1.40x0.10'] },
      { col1: 'GX2007', frequency: '6~12', data: ['22', '24', '35', '+8/-0.7', '2.15x1.50x0.10'] },
      { col1: 'GX2008', frequency: '6~12', data: ['24', '33', '45', '+8/-0.7', '2.70x2.75x0.10'] },
      { col1: 'GX2009', frequency: '6~18', data: ['20', '23', '25', '+8/-0.7', '2.15x1.45x0.10'] },
      { col1: 'GX2010', frequency: '6~18', data: ['22', '31', '20', '+7/-0.6', '2.90x2.75x0.10'] },
      { col1: 'GX2011', frequency: '6~18', data: ['24', '21', '20', '+4', '2.00x1.00x0.10'] },
      { col1: 'GX2012', frequency: '6~18', data: ['20', '22', '26', '+4', '2.00x1.00x0.10'] },
      { col1: 'GX2013', frequency: '6~18', data: ['20', '22', '24', '+4', '1.50x1.00x0.10'] },
      { col1: 'GX2014', frequency: '7.1~7.9', data: ['9', '38', '36', '+8/-0.7', '2.60x3.30x0.10'] },
      { col1: 'GX2015', frequency: '7.7~8.5', data: ['10', '37', '40', '+8/-0.7', '2.60x3.30x0.10'] },
      { col1: 'GX2016', frequency: '8~12', data: ['26', '35.5', '32', '+8/-0.7', '2.80x3.80x0.10'] },
      { col1: 'GX2017', frequency: '10~11', data: ['12', '40', '35', '+10/-0.7', '2.10x3.80x0.10'] },
      { col1: 'GX1049', frequency: '10~15', data: ['20', '24(输出P-1)', '-', '+5', '1.60x1.00x0.10'] },
      { col1: 'GX2032', frequency: '10~15', data: ['22', '24(输出P-1)', '-', '+5', '1.89x1.00x0.10'] },
      { col1: 'GX2018', frequency: '12.5~15', data: ['19', '34', '30', '+7/-0.7', '2.26x2.75x0.10'] },
      { col1: 'GX2019', frequency: '12.5~15', data: ['27', '36.5', '40', '+7/-0.7', '2.75x2.75x0.10'] },
      { col1: 'GX2020', frequency: '13~15', data: ['25', '34', '43', '+7/-0.7', '2.50x1.40x0.10'] },
      { col1: 'GX2021', frequency: '13~15', data: ['20', '35.5', '48', '+7/-0.7', '2.20x2.40x0.10'] },
      { col1: 'GX1064', frequency: '16~41', data: ['14', '16(输出P-1)', '-', '+4', '1.70x1.50x0.10'] },
      { col1: 'GX1061', frequency: '18~40', data: ['12', '13(输出P-1)', '-', '+4', '1.70x1.50x0.10'] },
      { col1: 'GX2033', frequency: '19~21', data: ['33.8', '18.2(输出P-1)', '-', '+4/-0.5', '1.65x0.74x0.10'] },
      { col1: 'GX2022', frequency: '22~32', data: ['16', '21', '27', '+4', '1.90x2.40x0.10'] },
      { col1: 'GX2023', frequency: '24~31', data: ['30', '20.2', '24', '+4/+0.6', '1.70x1.10x0.10'] },
      { col1: 'GX1052', frequency: '27~31', data: ['19', '23(输出P-1)', '-', '+5', '1.70x1.00x0.10'] },
      { col1: 'GX1053', frequency: '27~31', data: ['21.8', '23.2(输出P-1)', '-', '+5', '1.70x1.00x0.10'] }
    ],
    scrollLeft: 0,
    scrollTop: 0,
    showFilterPopup: false,
    isPopupVisible: false,
    filterValues: [],
    modelFilter: '',
    frequencyFilter: '',
    originalTableData: [],
    visibleTableData: [],
    visibleFrequencyData: [],
    rowHeight: 80,
    viewHeight: 800,
    currentPage: 1,
    pageSize: 10,
    totalPages: 0,
    isDataEmpty: false,
    activeFilters: []
  },

  updateVisibleData() {
    const { tableData, currentPage, pageSize } = this.data;
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, tableData.length);
    const visibleTableData = tableData.slice(startIndex, endIndex);
    const visibleFrequencyData = tableData.slice(startIndex, endIndex).map(item => item.frequency);
    this.setData({
      visibleTableData,
      visibleFrequencyData,
      scrollTop: 0,
      scrollLeft: 0
    });
  },

  firstPage() {
    if (this.data.currentPage !== 1) {
      this.setData({
        currentPage: 1
      });
      this.updateVisibleData();
    }
  },

  prevPage() {
    if (this.data.currentPage > 1) {
      this.setData({
        currentPage: this.data.currentPage - 1
      });
      this.updateVisibleData();
    }
  },

  nextPage() {
    if (this.data.currentPage < this.data.totalPages) {
      this.setData({
        currentPage: this.data.currentPage + 1
      });
      this.updateVisibleData();
    }
  },

  lastPage() {
    if (this.data.currentPage !== this.data.totalPages) {
      this.setData({
        currentPage: this.data.totalPages
      });
      this.updateVisibleData();
    }
  },

    syncScrollY(e) {
    const scrollTop = e.detail.scrollTop;
    this.setData({ scrollTop });
  },

  goToDetail(e) {
    const model = e.currentTarget.dataset.model;
    const rowData = this.data.tableData.find(item => item.col1 === model);
    const rowDataString = JSON.stringify(rowData);
    wx.navigateTo({
      url: `/pages/chipGaAsAMPd/detail/detail?rowData=${encodeURIComponent(rowDataString)}`
    });
  },

  openFilterPopup() {
    this.setData({
      showFilterPopup: true,
      isPopupVisible: true,
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: ''
    });
  },

  closeFilterPopup() {
    this.setData({ isPopupVisible: false });
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  inputFilter(e) {
    const index = e.currentTarget.dataset.index;
    const value = e.detail.value;
    let filterValues = this.data.filterValues;
    filterValues[index] = value;
    this.setData({ filterValues });
  },

  inputModelFilter(e) {
    const value = e.detail.value;
    this.setData({ modelFilter: value });
  },

  inputFrequencyFilter(e) {
    const value = e.detail.value;
    this.setData({ frequencyFilter: value });
  },

  applyFilter() {
    const { filterValues, modelFilter, frequencyFilter, originalTableData } = this.data;
    let filteredData = originalTableData;

    // 型号筛选
    if (modelFilter) {
      filteredData = filteredData.filter(row => 
        row.col1.toLowerCase().includes(modelFilter.toLowerCase())
      );
    }

    // 工作频率筛选
    if (frequencyFilter) {
      filteredData = filteredData.filter(row => {
        const rangeStr = row.frequency.replace('DC', '0');
        const [tableStart, tableEnd] = rangeStr.split('~').map(val => parseFloat(val.trim()));
        let inputStart, inputEnd;
        if (frequencyFilter.includes('~')) {
          [inputStart, inputEnd] = frequencyFilter.split('~').map(val => parseFloat(val.trim()));
        } else if (frequencyFilter.includes('-')) {
          [inputStart, inputEnd] = frequencyFilter.split('-').map(val => parseFloat(val.trim()));
        } else {
          inputStart = parseFloat(frequencyFilter);
          inputEnd = inputStart;
        }
        if (isNaN(inputStart) || isNaN(inputEnd) || isNaN(tableStart) || isNaN(tableEnd)) {
          return false;
        }
        return tableStart <= inputStart && tableEnd >= inputEnd;
      });
    }

    // 其他列筛选
    filteredData = filteredData.filter(row => {
      return row.data.every((cell, index) => {
        const filterValue = filterValues[index];
        if (!filterValue) return true;
        return cell.toString().toLowerCase().includes(filterValue.toLowerCase());
      });
    });

    // 收集当前应用的筛选条件
    const activeFilters = [];
    if (modelFilter) {
      activeFilters.push({ label: '型号', value: modelFilter });
    }
    if (frequencyFilter) {
      activeFilters.push({ label: '工作频率(GHz)', value: frequencyFilter });
    }
    filterValues.forEach((value, index) => {
      if (value) {
        activeFilters.push({ label: this.data.headerData[index], value });
      }
    });

    this.setData({
      isPopupVisible: false,
      activeFilters
    });

    setTimeout(() => {
      this.setData({
        tableData: filteredData,
        currentPage: 1,
        totalPages: Math.ceil(filteredData.length / this.data.pageSize),
        scrollTop: 0,
        showFilterPopup: false,
        isDataEmpty: filteredData.length === 0
      });
      this.updateVisibleData();
    }, 300);
  },

  clearFilter() {
    this.setData({
      tableData: this.data.originalTableData,
      currentPage: 1,
      totalPages: Math.ceil(this.data.originalTableData.length / this.data.pageSize),
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      frequencyFilter: '',
      isPopupVisible: false,
      scrollTop: 0,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  stopPropagation(e) {},

  onLoad(options) {
    const totalPages = Math.ceil(this.data.tableData.length / this.data.pageSize);
    this.setData({
      originalTableData: this.data.tableData,
      totalPages,
      currentPage: 1,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();

    // 处理从Search页面传递的筛选参数
    if (options.modelFilter || options.filterValues || options.frequencyFilter) {
      const modelFilter = options.modelFilter || '';
      const filterValues = options.filterValues ? JSON.parse(decodeURIComponent(options.filterValues)) : [];
      const frequencyFilter = options.frequencyFilter || '';
      this.setData({
        modelFilter,
        filterValues,
        frequencyFilter
      });
      this.applyFilter();
    }
  },

  onShareAppMessage: function () {
    // 函数体内容为空即可
  },

  onShareTimeline() {
    // 设置分享朋友圈内容
    return {
      title: '分享标题',
      query: 'key=value'
    }
  }
});
