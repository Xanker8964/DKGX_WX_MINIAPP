// pages/chipGaN/chipGaN.js
Page({
  clickGaNGLG:function(e){
    wx.navigateTo({
      url: '/pages/chipGaNpipe/chipGaNpipe'
    })
  }
  
})