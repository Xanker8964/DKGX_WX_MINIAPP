Page({
  data: {
    showPrivacyPopup: false // 控制隐私弹窗显示
  },

  onLoad: function () {
    // 检查是否需要显示隐私授权弹窗
    const hasAgreed = wx.getStorageSync('privacyAgreed');
    console.log('Privacy Agreed Status:', hasAgreed); // 调试：检查存储状态
    if (!hasAgreed) {
      this.setData({
        showPrivacyPopup: true
      });
      console.log('Show Privacy Popup:', this.data.showPrivacyPopup); // 调试：确认弹窗状态
    }
  },

  // 同意隐私协议
  agreePrivacy: function () {
    wx.setStorageSync('privacyAgreed', true);
    this.setData({
      showPrivacyPopup: false
    });
    console.log('Privacy Agreed, Popup Closed'); // 调试：确认同意操作
  },

  // 拒绝隐私协议
  disagreePrivacy: function () {
    wx.showToast({
      title: '您需要同意来使用本小程序',
      icon: 'none',
      duration: 2000
    });
    console.log('Privacy Disagreed'); // 调试：确认拒绝操作
  },

  // 关闭弹窗
  closePopup: function () {
    wx.setStorageSync('privacyAgreed', true); // 关闭窗口视为同意
    this.setData({
      showPrivacyPopup: false
    });
    console.log('Popup Closed'); // 调试：确认关闭操作
  },

  // 阻止事件冒泡
  stopPropagation: function (e) {
    // 调试：检查事件对象
    console.log('Event Object:', e);
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation(); // 阻止事件冒泡
      console.log('Stop Propagation Success'); // 调试：确认阻止冒泡
    } else {
      console.warn('stopPropagation is not a function or event is invalid');
    }
  },

  Fangdaqi1: function () {
    wx.navigateTo({
      url: '/pages/Fangdaqi01/fangdaqi01'
    });
  },

  clickGaN2: function () {
    wx.navigateTo({
      url: '/pages/Fuxiang/fuxiang'
    });
  },

  clickFZ2: function () {
    wx.navigateTo({
      url: '/pages/Fengzhuang/fzhuang'
    });
  },

  clickWY: function () {
    wx.navigateTo({
      url: '/pages/Wuyuan/wuyuan'
    });
  },

  clickKG: function () {
    wx.navigateTo({
      url: '/pages/chipKaiguan/chipKaiguan'
    });
  },

  clickCMOS3: function () {
    wx.navigateTo({
      url: '/pages/chipCMOS/chipCMOS'
    });
  },

  clickmore4: function () {
    wx.navigateTo({
      url: '/pages/chipmore/chipgenduo'
    });
  },
 
  onShareAppMessage: function () {
    // 函数体内容为空即可
},
  onShareTimeline() {
  // 设置分享朋友圈内容
  return {
    title: '分享标题',
    query: 'key=value'
  }
}
});