Page({
  data: {
    headerData: ['功能', '工作电源(V)', '峰值电流(A)', '上升延时(ns)', '下降延时(ns)', '芯片尺寸(mm)'],
    tableData: [
      { col1: 'GX2201P', data: ['PMOSFET漏级驱动器', '12~32', '14', '60', '16.4', 'T/SLP 5x5'] },
      { col1: 'GX2202P', data: ['MOSFET驱动器', '4~12', '-', '30', '19', 'T/SLP 3x3'] }
    ],
    scrollLeft: 0,
    scrollTop: 0,
    showFilterPopup: false,
    isPopupVisible: false,
    filterValues: [],
    modelFilter: '',
    originalTableData: [],
    visibleTableData: [],
    rowHeight: 80,
    viewHeight: 800,
    currentPage: 1,
    pageSize: 10,
    totalPages: 0,
    isDataEmpty: false,
    activeFilters: [] // 新增字段，存储当前应用的筛选条件
  },

  updateVisibleData() {
    const { tableData, currentPage, pageSize } = this.data;
    const startIndex = (currentPage - 1) * pageSize;
    const endIndex = Math.min(startIndex + pageSize, tableData.length);
    const visibleTableData = tableData.slice(startIndex, endIndex);
    this.setData({
      visibleTableData,
      scrollTop: 0,
      scrollLeft: 0
    });
  },

  firstPage() {
    if (this.data.currentPage !== 1) {
      this.setData({
        currentPage: 1
      });
      this.updateVisibleData();
    }
  },

  prevPage() {
    if (this.data.currentPage > 1) {
      this.setData({
        currentPage: this.data.currentPage - 1
      });
      this.updateVisibleData();
    }
  },

  nextPage() {
    if (this.data.currentPage < this.data.totalPages) {
      this.setData({
        currentPage: this.data.currentPage + 1
      });
      this.updateVisibleData();
    }
  },

  lastPage() {
    if (this.data.currentPage !== this.data.totalPages) {
      this.setData({
        currentPage: this.data.totalPages
      });
      this.updateVisibleData();
    }
  },

  syncScrollY(e) {
    const scrollTop = e.detail.scrollTop;
    this.setData({ scrollTop });
  },

  goToDetail(e) {
    const model = e.currentTarget.dataset.model;
    const rowData = this.data.tableData.find(item => item.col1 === model);
    const rowDataString = JSON.stringify(rowData);
    wx.navigateTo({
      url: `/pages/chipCMOS/detail/detail?rowData=${encodeURIComponent(rowDataString)}`
    });
  },

  openFilterPopup() {
    this.setData({
      showFilterPopup: true,
      isPopupVisible: true,
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: ''
    });
  },

  closeFilterPopup() {
    this.setData({ isPopupVisible: false });
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  inputFilter(e) {
    const index = e.currentTarget.dataset.index;
    const value = e.detail.value;
    let filterValues = this.data.filterValues;
    filterValues[index] = value;
    this.setData({ filterValues });
  },

  inputModelFilter(e) {
    const value = e.detail.value;
    this.setData({ modelFilter: value });
  },

  applyFilter() {
    const filterValues = this.data.filterValues;
    const modelFilter = this.data.modelFilter;
    const originalData = this.data.originalTableData;
  
    let filteredData = originalData;
  
    // 型号筛选
    if (modelFilter) {
      filteredData = filteredData.filter(row => 
        row.col1.toLowerCase().includes(modelFilter.toLowerCase())
      );
    }
  
    // 按列筛选
    filteredData = filteredData.filter(row => {
      return row.data.every((cell, index) => {
        const filterValue = filterValues[index];
        if (!filterValue) return true;
  
        // 特殊处理工作电源列 (index === 1)
        if (index === 1) {
          // 替换 DC 为 0
          const rangeStr = cell.replace('DC', '0');
          // 解析电源范围，例如 "12~32" 或 "4~12"
          const [tableStart, tableEnd] = rangeStr.split('~').map(val => parseFloat(val.trim()));
          
          // 解析输入的范围，例如 "0.1~3.5" 或 "0.2-3.9"
          let inputStart, inputEnd;
          if (filterValue.includes('~')) {
            [inputStart, inputEnd] = filterValue.split('~').map(val => parseFloat(val.trim()));
          } else if (filterValue.includes('-')) {
            [inputStart, inputEnd] = filterValue.split('-').map(val => parseFloat(val.trim()));
          } else {
            // 兼容单个数值输入
            inputStart = parseFloat(filterValue);
            inputEnd = inputStart;
          }
  
          // 检查输入范围是否有效
          if (isNaN(inputStart) || isNaN(inputEnd) || isNaN(tableStart) || isNaN(tableEnd)) {
            return false;
          }
  
          // 检查表格范围是否包含输入范围（包括端点）
          return tableStart <= inputStart && inputEnd <= tableEnd;
        }
  
        // 其他列保持字符串包含逻辑
        return cell.toString().toLowerCase().includes(filterValue.toLowerCase());
      });
    });
  
    // 收集当前应用的筛选条件
    const activeFilters = [];
    if (modelFilter) {
      activeFilters.push({ label: '型号', value: modelFilter });
    }
    filterValues.forEach((value, index) => {
      if (value) {
        activeFilters.push({ label: this.data.headerData[index], value });
      }
    });
  
    this.setData({
      isPopupVisible: false,
      activeFilters // 更新筛选条件显示
    });
  
    setTimeout(() => {
      this.setData({
        tableData: filteredData,
        currentPage: 1,
        totalPages: Math.ceil(filteredData.length / this.data.pageSize),
        scrollTop: 0,
        showFilterPopup: false,
        isDataEmpty: filteredData.length === 0
      });
      this.updateVisibleData();
    }, 300);
  },

  clearFilter() {
    this.setData({
      tableData: this.data.originalTableData,
      currentPage: 1,
      totalPages: Math.ceil(this.data.originalTableData.length / this.data.pageSize),
      filterValues: new Array(this.data.headerData.length).fill(''),
      modelFilter: '',
      isPopupVisible: false,
      scrollTop: 0,
      isDataEmpty: false,
      activeFilters: [] // 清空筛选条件
    });
    this.updateVisibleData();
    setTimeout(() => {
      this.setData({ showFilterPopup: false });
    }, 300);
  },

  stopPropagation(e) {},

onLoad(options) {
    const totalPages = Math.ceil(this.data.tableData.length / this.data.pageSize);
    this.setData({
      originalTableData: this.data.tableData,
      totalPages,
      currentPage: 1,
      isDataEmpty: false,
      activeFilters: []
    });
    this.updateVisibleData();

    // 处理从Search页面传递的筛选参数
    if (options.modelFilter || options.filterValues) {
      const modelFilter = options.modelFilter || '';
      const filterValues = options.filterValues ? JSON.parse(decodeURIComponent(options.filterValues)) : [];
      this.setData({
        modelFilter,
        filterValues
      });
      this.applyFilter({ modelFilter, filterValues });
    }
  },
  onShareAppMessage: function () {
    // 函数体内容为空即可
},
  onShareTimeline() {
  // 设置分享朋友圈内容
  return {
    title: '分享标题',
    query: 'key=value'
  }
}
});