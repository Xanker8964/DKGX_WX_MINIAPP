Page({
  data: {
    rowData: null,
    headerData: [ '工作频段', '额定功率', '功率增益'],
    isDownloading: false
  },

    onLoad(options) {
    if (options.rowData) {
      const rowData = JSON.parse(decodeURIComponent(options.rowData));
      this.setData({
        rowData: rowData
      });
      // 动态设置导航栏标题为产品型号
      wx.setNavigationBarTitle({
        title: rowData.col1 || '产品详情'
      });
    }
  },

  downloadPDF() {
    if (this.data.isDownloading) return;
    this.setData({ isDownloading: true });

    const model = this.data.rowData?.col1;
    if (!model) {
      wx.showToast({
        title: '型号为空',
        icon: 'none'
      });
      this.setData({ isDownloading: false });
      return;
    }

    const filePath = `cloud://w1-6guirxds740b98c2.7731-w1-6guirxds740b98c2-1334753517/dkgxcp/gongfang/SSPA/${model}.pdf`;
    console.log('文件路径:', filePath); // 调试用
    wx.showLoading({
      title: '下载中...',
    });

    wx.cloud.getTempFileURL({
      fileList: [filePath],
      success: (res) => {
        const fileResult = res.fileList[0];
        if (fileResult.status === 0 && fileResult.tempFileURL) {
          const tempFileURL = fileResult.tempFileURL;
          wx.downloadFile({
            url: tempFileURL,
            success(downloadRes) {
              const filePath = downloadRes.tempFilePath;
              wx.openDocument({
                filePath: filePath,
                showMenu: true,
                fileType: 'pdf',
                success() {
                  wx.hideLoading();
                  wx.showToast({
                    title: '打开成功',
                    icon: 'success'
                  });
                },
                fail(err) {
                  wx.hideLoading();
                  wx.showToast({
                    title: '打开失败',
                    icon: 'none'
                  });
                  console.error('打开 PDF 失败', err);
                }
              });
            },
            fail(err) {
              wx.hideLoading();
              wx.showToast({
                title: '下载失败',
                icon: 'none'
              });
              console.error('下载 PDF 失败', err);
            }
          });
        } else {
          wx.hideLoading();
          wx.showToast({
            title: '文件不存在或无权限',
            icon: 'none'
          });
          console.error('文件获取失败', fileResult);
        }
      },
      fail(err) {
        wx.hideLoading();
        wx.showToast({
          title: '获取 URL 失败',
          icon: 'none'
        });
        console.error('调用 getTempFileURL 失败', err);
      },
      complete: () => {
        this.setData({ isDownloading: false });
      }
    });
  }
});