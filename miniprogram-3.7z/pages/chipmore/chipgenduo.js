// pages/chipmore/chipmore.js
Page({
  clickSSPA:function(e){
    wx.navigateTo({
      url: '/pages/SSPA/SSPA'
    })
  },

  clickBUC:function(e){
    wx.navigateTo({
      url: '/pages/BUC/BUC'
    })
  },

  clickXinghaoyuan:function(e){
    wx.navigateTo({
      url: '/pages/Xinghaoyuan/Xinghaoyuan'
    })
  }
  
})