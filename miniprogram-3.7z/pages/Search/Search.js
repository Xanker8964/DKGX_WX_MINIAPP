// pages/Search/Search.js
Page({
  data: {
    categories: [
      { 
        name: '两路功分器芯片', 
        page: 'chip2waygongfen', 
        headerData: ['插损(dB)', '隔离度(dB)', '输入回波损耗(dB)', '输出回波损耗(dB)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '三路功分器芯片', 
        page: 'chip3waygongfen', 
        headerData: ['插损(dB)', '隔离度(dB)', '输入回波损耗(dB)', '输出回波损耗(dB)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: 'CMOS驱动器芯片', 
        page: 'chipCMOS', 
        headerData: ['功能', '工作电源(V)', '峰值电流(A)', '上升延时(ns)', '下降延时(ns)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: 'GaAs功放芯片', 
        page: 'chipGaAsAMPd', 
        headerData: ['增益(dB)', '输出Psat(dBm)', '效率(%)', '电源(V/Vg)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: 'GaAs低噪放芯片', 
        page: 'chipGaAsLowamp', 
        headerData: ['增益(dB)', '噪声系数(dB)', '输出P-1dB(dBm)', '电源(V/mA)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: 'GaN功率放大器', 
        page: 'chipGaNampd', 
        headerData: ['功率增益(dB)', '输出Psat(dBm)', '效率(%)', '电源(V)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: 'GaN功率管', 
        page: 'chipGaNpipe', 
        headerData: ['增益(dB)', '输出功率(W)', '效率(%)', '电源(V)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '固定衰减器芯片', 
        page: 'chipGudingsj', 
        headerData: ['衰减量(dB)', '输入回波损耗(dB)', '输出回波损耗(dB)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '混频器芯片', 
        page: 'chipHunping', 
        headerData: ['中频范围(GHz)', '变换损耗(dB)', 'LO-RF隔离度(dB)', 'LO-IF隔离度(dB)', 'RF-IF隔离度(dB)', '本振功率(dBm)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '均衡器芯片', 
        page: 'chipJunheng', 
        headerData: ['插损(dB)', '均衡量(dB)', '输入回波损耗(dB)', '输出回波损耗(dB)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '开关芯片', 
        page: 'chipKaiguan', 
        headerData: ['类型', '插损(dB)', '隔离度(dB)', '输入/输出回波损耗(dB)', '1dB压缩输出功率(dBm)', '控制电平(V)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '可变衰减器芯片', 
        page: 'chipKebiansj', 
        headerData: ['衰减量(dB)', '输入回波损耗(dB)', '输出回波损耗(dB)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '耦合器芯片', 
        page: 'chipOuhe', 
        headerData: ['插损(dB)', '耦合度(dB)', '输入回波损耗(dB)', '直通输出回波损耗(dB)', '耦合输出回波损耗(dB)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '数控衰减器芯片', 
        page: 'chipShukongsj', 
        headerData: ['位数(bit)', '插损(dB)', '衰减范围(dB)', '附加相移(◦)', '输入驻波', '输出驻波', '控制电平(V)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '数控移相器芯片', 
        page: 'chipShukongyx', 
        headerData: ['位数(bit)', '插损(dB)', '移相范围(◦)', '幅度调制(dB)', '输入驻波', '输出驻波', '控制电平(V)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      },
      { 
        name: '限幅器芯片', 
        page: 'chipXianfu', 
        headerData: ['插损(dB)', '限幅电平(dB)', '耐功率(dBm)', '输入回波损耗(dB)', '输出回波损耗(dB)', '芯片尺寸(mm)'], 
        rangeFilterCols: [] 
      }
    ],
    selectedCategoryIndex: 0,
    filterItems: [],
    filterValues: [],
    modelFilter: '',
    frequencyFilter: '',
    rangeFilterTips: []
  },

  onLoad() {
    // 初始化筛选项
    this.updateFilterItems();
  },

  onCategoryChange(e) {
    const index = e.detail.value;
    this.setData({
      selectedCategoryIndex: index,
      modelFilter: '',
      frequencyFilter: '',
      filterValues: []
    });
    this.updateFilterItems();
  },

  updateFilterItems() {
    const category = this.data.categories[this.data.selectedCategoryIndex];
    const filterItems = category.headerData;
    const rangeFilterTips = category.rangeFilterCols.map(col => filterItems[col]);
    this.setData({
      filterItems,
      filterValues: new Array(filterItems.length).fill(''),
      rangeFilterTips
    });
  },

  inputModelFilter(e) {
    this.setData({ modelFilter: e.detail.value });
  },

  inputFrequencyFilter(e) {
    this.setData({ frequencyFilter: e.detail.value });
  },

  inputFilter(e) {
    const index = e.currentTarget.dataset.index;
    const value = e.detail.value;
    let filterValues = this.data.filterValues;
    filterValues[index] = value;
    this.setData({ filterValues });
  },

  clearFilter() {
    this.setData({
      modelFilter: '',
      frequencyFilter: '',
      filterValues: new Array(this.data.filterItems.length).fill('')
    });
  },

  doSearch() {
    const category = this.data.categories[this.data.selectedCategoryIndex];
    const queryParams = {
      modelFilter: this.data.modelFilter,
      frequencyFilter: this.data.frequencyFilter,
      filterValues: JSON.stringify(this.data.filterValues)
    };
    wx.navigateTo({
      url: `/pages/${category.page}/${category.page}?${this.objToQueryString(queryParams)}`
    });
  },

  objToQueryString(obj) {
    return Object.keys(obj).map(key => `${key}=${encodeURIComponent(obj[key])}`).join('&');
  },

  onShareAppMessage() {
    return {
      title: '产品查询',
      path: '/pages/Search/Search'
    };
  },

  onShareTimeline() {
    return {
      title: '产品查询',
      query: 'page=Search'
    };
  }
});